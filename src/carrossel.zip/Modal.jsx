import { useState } from "react";

function Modal({ onClose }) {
  const [question, SetQuestion] = useState(0);
  const [finish, setFinish] = useState(false);
  const [answers, setAnswers] = useState({
    Pergunta1: null,
    Pergunta2: null,
    Pergunta3: null,
    Observacao: "",
  });
  const Questions = [
    {
      id: "Pergunta1",
      texto: "Nossa equipe prestou um atendimento de qualidade?",
      tipo: "Nota",
    },
    {
      id: "Pergunta2",
      texto: "O nosso espaço estava limpo e organizado?",
      tipo: "Nota",
    },
    {
      id: "Pergunta3",
      texto: "O buffet estava abastecido e com variedade de opções?",
      tipo: "Nota",
    },
    {
      id: "Observacao",
      texto:
        "Deixe aqui sua observação ou sugestão para melhorarmos ainda mais!",
      tipo: "texto",
    },
  ];

  const next = () => {
    if (question < Questions.length - 1) {
      SetQuestion(question + 1);
    }
  };

  const prev = () => {
    if (question > 0) {
      SetQuestion(question - 1);
    }
  };

  const handleCancel = () => {
    if (typeof onClose === "function") {
      onClose();
    }
  };

  const handleAnswer = (num) => {
    const perguntaATUAL = Questions[question].id;

    setAnswers((prev) => ({
      ...prev,
      [perguntaATUAL]: num,
    }));
  };

  const handleSubmit = () => {
    const data = {
      ...answers,
      horario: new Date().toISOString(),
    };

    console.log("horário enviado:", data);
    setFinish(true);
    setTimeout(() => {
      onClose();
    }, 2000);
  };

  return (
    <div className="ModalOverlay">
      <div className="modalContainer">
        {finish ? (
          <div className="finishContainer">
            <div className="checkIcon">✓</div>
            <h1>obrigado por participar!</h1>
            <p>Sua opinião nos ajuda a melhorar.</p>
          </div>
        ) : (
          <>
            <div className="modalHeader">
              <button className="closeBtn" onClick={handleCancel}>
                X
              </button>

              <span>
                {question + 1}/{Questions.length}
              </span>
            </div>

            <div className="modalQuestion">
              <h1>{Questions[question].texto}</h1>
            </div>

            {Questions[question].tipo === "Nota" && (
              <div className="avaliacao">
                {[1, 2, 3, 4, 5].map((num) => (
                  <button
                    key={num}
                    className={`nota nota-${num} ${
                      answers[`Pergunta${question + 1}`] === num
                        ? "selecionado"
                        : ""
                    }`}
                    onClick={() => handleAnswer(num)}
                  >
                    {num}
                  </button>
                ))}
              </div>
            )}

            {Questions[question].tipo === "texto" && (
              <div className="observacao">
                <textarea
                  placeholder="Digite sua sugestão..."
                  onChange={(e) =>
                    setAnswers((prev) => ({
                      ...prev,
                      Observacao: e.target.value,
                    }))
                  }
                />
              </div>
            )}
            <div className="navigation">
              <div className="navLeft">
                {question > 0 && (
                  <button className="voltarBtn" onClick={prev}>
                    Voltar
                  </button>
                )}
              </div>
              <div className="navRight">
                {question < Questions.length - 1 &&
                  answers[`Pergunta${question + 1}`] && (
                    <button className="nextBtn" onClick={next}>
                      Avançar
                    </button>
                  )}
                {question === Questions.length - 1 && (
                  <button className="submitBtn" onClick={handleSubmit}>
                    Enviar
                  </button>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default Modal;
